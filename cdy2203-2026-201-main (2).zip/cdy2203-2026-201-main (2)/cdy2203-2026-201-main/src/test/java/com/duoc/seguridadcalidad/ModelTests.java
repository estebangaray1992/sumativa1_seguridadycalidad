package com.duoc.seguridadcalidad;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ModelTests {

    @Test
    void testInvoiceModel() {
        Invoice invoice = new Invoice();
        invoice.setId(1L);
        invoice.setTotal(100.0);
        
        assertEquals(1L, invoice.getId());
        assertEquals(100.0, invoice.getTotal());
    }

    @Test
    void testAppointmentModel() {
        Appointment app = new Appointment();
        app.setId(1L);
        app.setReason("Consulta");
        
        assertEquals(1L, app.getId());
        assertEquals("Consulta", app.getReason());
    }
}
