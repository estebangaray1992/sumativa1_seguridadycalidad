package com.duoc.seguridadcalidad;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean; // Paquete para Spring Boot 3.4
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class PatientRestControllersTests {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean // Se usa MockitoBean en lugar de MockBean en la 3.4.0
    private PatientRepository patientRepository;

    @Test
    void testGetAllPatients() throws Exception {
        mockMvc.perform(get("/api/patients"))
               .andExpect(status().isOk());
    }
}